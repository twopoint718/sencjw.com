/* Basic Lisp highlighting by Chris Wilson  */
dp.sh.Brushes.Lisp = function()
{
  var keywords =  'and car cons cdr cadr cddr continue defun defmacro ' +
  'or loop while when setf setq getf make-hash-table do ' +
  'atomp null not destructuring-bind list defparameter listp' +
  'read format let with-open-file gethash lambda oddp evenp ' +
  'defgeneric defmethod if progn first second third read-delimited-list ' +
  'set-macro-character set-dispatch-macro-character';
                    

  var special =  'nil t T CL-USER'

  this.regexList = [
{ regex: new RegExp(";.*$"), css: 'comment' },
{ regex: new RegExp("^\\s*@\\w+", 'gm'), css: 'decorator' },
{ regex: new RegExp('"(?!")(?:\\.|\\\\\\"|[^\\""\\n\\r])*"', 'gm'), css: 'string' },
{ regex: new RegExp("'(?!')*(?:\\.|(\\\\\\')|[^\\''\\n\\r])*'", 'gm'), css: 'string' },
{ regex: new RegExp("\\b\\d+\\.?\\w*", 'g'), css: 'number' },
{ regex: new RegExp(this.GetKeywords(keywords), 'gm'), css: 'keyword' },
{ regex: new RegExp(this.GetKeywords(special), 'gm'), css: 'special' },
{ regex: new RegExp(":\\w+", 'gm'), css: 'uninter' }
                    ];

    this.CssClass = 'dp-py';
	this.Style =	'.dp-py .uninter { color: #118833; }' +
                    '.dp-py .number { color: #991122; }' +
                    '.dp-py .builtins { color: #ff1493; }' +
					'.dp-py .magicmethods { color: #808080; }' +
                    '.dp-py .special { font-style: bold; }' +
					'.dp-py .exceptions { color: brown; }' +
					'.dp-py .types { color: brown; font-style: italic; }' +
					'.dp-py .commonlibs { color: #8A2BE2; font-style: italic; }';
}

dp.sh.Brushes.Lisp.prototype  = new dp.sh.Highlighter();
dp.sh.Brushes.Lisp.Aliases    = ['lisp', 'lsp'];
